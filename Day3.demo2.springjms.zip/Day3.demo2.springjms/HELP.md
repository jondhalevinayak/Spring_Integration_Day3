# Getting Started

### Guides
The following guides illustrates how to use certain features concretely:

* [Messaging with JMS](https://spring.io/guides/gs/messaging-jms/)

